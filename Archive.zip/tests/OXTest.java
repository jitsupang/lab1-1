import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OXTest {
    @Test
    public void shouldCreateOxObjectCorrectly(){
        OX ox = new OX();
        //" 012\n0---\n1---\n2---\n"
        assertEquals(" 012\n0---\n1---\n2---\n",OX.getTableString());
        assertEquals("X", OX.getCurrentPlayer());
        assertEquals(0, OX.getcountO());
        assertEquals(0, OX.getcountX());
        assertEquals(0, OX.getcountDraw());

    }

    @Test
    public void put(){
        OX ox = new OX();
        OX.put(1,1);
        assertEquals(" 012\n0---\n1-X-\n2---\n",OX.getTableString());


    }
}