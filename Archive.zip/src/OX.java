public class OX {
    private static String[][] table = {
            {" ", "0", "1", "2"},
            {"0", "-", "-", "-"},
            {"1", "-", "-", "-"},
            {"2", "-", "-", "-"},
    };

    private static String player;
    private static int countX;
    private static int countO;
    private static int countDraw;

    public OX(){
        player = "X";
        countX = 0;
        countO = 0;
        countDraw = 0;

    }

    public static String getTableString() {
        String result = "";
        for(int row = 0; row<table.length; row++){
            for(int col = 0; col<table[row].length; col++){
                result  = result + table[row][col];
            }
            result = result + "\n";
        }
        return result;
    }

    public static String getCurrentPlayer() {
        return player;
    }

    public static int getcountO() {
        return countO;
    }

    public static int getcountX() {
        return countX;
    }

    public static int getcountDraw() {
        return countDraw;
    }

    public static void put(int col, int row) {
        table[row+1][col+1] = "X";
    }
}
